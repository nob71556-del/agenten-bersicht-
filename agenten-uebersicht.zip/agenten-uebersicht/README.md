# Agenten-Anzeige

Ein Mod für Claude: ein Seitenpanel namens "Agenten", das live zeigt, welcher Agent gerade arbeitet, was er gerade macht (zum Beispiel "nutzt Bash") und welche Agenten schon fertig sind. Das Panel öffnet sich beim Start eines Chats und sobald ein Agent startet. Mit dem Befehl /agenten lässt es sich jederzeit wieder öffnen.

## Installation

In der Desktop-App: auf + neben dem Eingabefeld klicken, dann Plugins, dann Add marketplace mit dem Namen dieses Repositorys, dann Add plugin.

Im Terminal:

```
/plugin install agenten-anzeige --marketplace <github-name>/agenten-uebersicht
```
