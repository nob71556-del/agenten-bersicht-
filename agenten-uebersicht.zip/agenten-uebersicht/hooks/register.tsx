import { atom, read, update } from 'claude-code'
import type { Register } from 'claude-code'

import type { AgentRow } from '../types'

const PANE = 'agenten-anzeige'
const agents = atom({ plugin: 'agenten-anzeige', key: 'agents' } as const, [], {
  shape: 'agents-1',
})

const setRow = (id: string, patch: Partial<AgentRow>) => (list: AgentRow[]) =>
  list.map(row => (row.id === id ? { ...row, ...patch } : row))

export const register: Register = on => {
  on('session.start', async ($, e, next) => {
    await $.command.register({
      name: 'agenten',
      description: 'Zeigt im Seitenpanel, was die Agenten gerade machen',
    })
    void $.ui.open({ id: PANE, title: 'Agenten' })

    return next(e)
  })

  on('command.run', { command: 'agenten' }, async $ => {
    await $.ui.open({ id: PANE, title: 'Agenten' })

    return { text: 'Agenten-Panel geöffnet.' }
  })

  // Ein neuer Agent startet
  on('agent.spawn', async ($, e, next) => {
    const started = await next(e)
    void $.ui.open({ id: PANE, title: 'Agenten' })
    const id = started.agentId
    if (id !== undefined) {
      const row: AgentRow = {
        id,
        name: e.description || e.subagentType,
        type: e.subagentType,
        doing: 'startet …',
        status: 'runs',
      }
      await update($, agents, list => [...list.filter(r => r.id !== id), row].slice(-30))
    }

    return started
  })

  // Ein Agent benutzt gerade ein Werkzeug
  on('tool.call', async ($, e, next) => {
    const id = e.agentId
    if (id !== undefined) {
      await update($, agents, setRow(id, { doing: `nutzt ${e.tool}`, status: 'runs' }))
    }

    return next(e)
  })

  // Ein Agent ist fertig
  on('turn.complete', async ($, e, next) => {
    const id = e.agentId
    if (id !== undefined) {
      await update($, agents, setRow(id, { doing: 'fertig', status: 'done' }))
    }

    return next(e)
  })

  on('ui.render', { component: 'Pane', requestId: PANE }, async ($, e) => {
    const { Box, Text } = $.ui.resolve(e)
    const list = await read($, agents)
    const running = list.filter(r => r.status === 'runs')
    const done = list.filter(r => r.status === 'done')
    const room = Math.max(1, (e.viewport?.rows ?? 24) - 6)

    return (
      <Box flexDirection="column">
        <Text bold>
          {running.length === 0 ? 'Gerade arbeitet kein Agent' : `${running.length} Agent(en) arbeiten gerade`}
        </Text>
        <Text> </Text>
        {running.slice(-room).map(r => (
          <Box flexDirection="column">
            <Text bold color="green">● {r.name}</Text>
            <Text>   {r.doing}</Text>
          </Box>
        ))}
        {done.length > 0 && <Text> </Text>}
        {done.slice(-5).map(r => (
          <Text dimColor>✓ {r.name} – fertig</Text>
        ))}
      </Box>
    )
  })
}
