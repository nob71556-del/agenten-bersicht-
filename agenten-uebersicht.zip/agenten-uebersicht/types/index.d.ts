export type AgentRow = {
  id: string
  name: string
  type: string
  doing: string
  status: 'runs' | 'done'
}

declare module 'claude-code' {
  interface PluginState {
    'agenten-anzeige': { agents: Shaped<AgentRow[]> }
  }
}
